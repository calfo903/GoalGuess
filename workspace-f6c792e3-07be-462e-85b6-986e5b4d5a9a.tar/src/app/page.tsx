'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Trophy, 
  TrendingUp, 
  Users, 
  Calendar,
  Clock,
  Flag,
  Target,
  Zap,
  Shield,
  Star,
  ChevronRight,
  Play,
  Pause,
  RefreshCw,
  Soccer,
  BarChart3,
  MapPin,
  Eye,
  ThumbsUp,
  ThumbsDown,
  Wifi,
  WifiOff,
  Bell,
  History,
  CalendarDays,
  TrendingDown,
  Home,
  User,
  Timer,
  Tv,
  Award,
  TargetIcon
} from 'lucide-react'

interface Match {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  status: 'live' | 'finished' | 'upcoming'
  minute?: number
  league: string
  leagueFlag: string
  homeLogo?: string
  awayLogo?: string
  venue?: string
  attendance?: number
  prediction?: {
    winner: string
    confidence: number
    tips: string[]
    reasoning?: string
  }
  homeTeamStats?: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
  }
  awayTeamStats?: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
  }
  lastUpdate?: Date
}

interface Fixture {
  id: string
  homeTeam: string
  awayTeam: string
  date: string
  time: string
  league: string
  leagueFlag: string
  venue: string
  status: string
  matchday: string | number
  broadcast: string
  referee: string
}

interface PreviousGame {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  date: string
  time: string
  league: string
  leagueFlag: string
  venue: string
  status: string
  matchday: string | number
  attendance: number
  homeTeamStats: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
    xG: number
    xGA: number
  }
  awayTeamStats: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
    xG: number
    xGA: number
  }
  goalscorers: Array<{
    player: string
    team: string
    minute: number
    type: string
  }>
  manOfTheMatch: string
}

interface HeadToHead {
  team1: string
  team2: string
  totalMatches: number
  team1Wins: number
  team2Wins: number
  draws: number
  team1Goals: number
  team2Goals: number
  last5Matches: Array<{
    date: string
    homeTeam: string
    awayTeam: string
    homeScore: number
    awayScore: number
    result: string
  }>
}

interface TeamForm {
  opponent: string
  result: string
  score: string
  home: boolean
}

const initialMatches: Match[] = [
  {
    id: '1',
    homeTeam: 'Manchester City',
    awayTeam: 'Liverpool',
    homeScore: 2,
    awayScore: 1,
    status: 'live',
    minute: 67,
    league: 'Premier League',
    leagueFlag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿',
    venue: 'Etihad Stadium',
    attendance: 55000,
    homeTeamStats: {
      possession: 62,
      shots: 14,
      shotsOnTarget: 6,
      corners: 7,
      fouls: 8,
      yellowCards: 1,
      redCards: 0
    },
    awayTeamStats: {
      possession: 38,
      shots: 8,
      shotsOnTarget: 3,
      corners: 3,
      fouls: 12,
      yellowCards: 2,
      redCards: 0
    }
  },
  {
    id: '2',
    homeTeam: 'Real Madrid',
    awayTeam: 'Barcelona',
    homeScore: 0,
    awayScore: 0,
    status: 'live',
    minute: 34,
    league: 'La Liga',
    leagueFlag: '🇪🇸',
    venue: 'Santiago Bernabéu',
    attendance: 80000,
    homeTeamStats: {
      possession: 55,
      shots: 9,
      shotsOnTarget: 2,
      corners: 4,
      fouls: 6,
      yellowCards: 1,
      redCards: 0
    },
    awayTeamStats: {
      possession: 45,
      shots: 7,
      shotsOnTarget: 2,
      corners: 2,
      fouls: 9,
      yellowCards: 2,
      redCards: 0
    }
  },
  {
    id: '3',
    homeTeam: 'Bayern Munich',
    awayTeam: 'Borussia Dortmund',
    homeScore: 3,
    awayScore: 2,
    status: 'finished',
    league: 'Bundesliga',
    leagueFlag: '🇩🇪',
    venue: 'Allianz Arena',
    attendance: 75000,
    homeTeamStats: {
      possession: 58,
      shots: 18,
      shotsOnTarget: 8,
      corners: 9,
      fouls: 10,
      yellowCards: 2,
      redCards: 0
    },
    awayTeamStats: {
      possession: 42,
      shots: 12,
      shotsOnTarget: 5,
      corners: 4,
      fouls: 14,
      yellowCards: 3,
      redCards: 1
    }
  },
  {
    id: '4',
    homeTeam: 'PSG',
    awayTeam: 'Marseille',
    homeScore: 0,
    awayScore: 0,
    status: 'upcoming',
    league: 'Ligue 1',
    leagueFlag: '🇫🇷',
    venue: 'Parc des Princes',
    attendance: 0
  }
]

export default function Home() {
  const [matches, setMatches] = useState<Match[]>(initialMatches)
  const [fixtures, setFixtures] = useState<Fixture[]>([])
  const [previousGames, setPreviousGames] = useState<PreviousGame[]>([])
  const [headToHead, setHeadToHead] = useState<HeadToHead[]>([])
  const [teamForms, setTeamForms] = useState<Record<string, TeamForm[]>>({})
  const [leagues, setLeagues] = useState<any[]>([])
  const [topScorers, setTopScorers] = useState<any[]>([])
  const [teamStats, setTeamStats] = useState<any[]>([])
  const [selectedTab, setSelectedTab] = useState('livescore')
  const [selectedLeague, setSelectedLeague] = useState('all')
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [loading, setLoading] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [notifications, setNotifications] = useState<string[]>([])
  const socketRef = useRef<any>(null)

  useEffect(() => {
    fetchLeagues()
    fetchStats()
    fetchFixtures()
    fetchPreviousGames()
    fetchHeadToHead()
    fetchTeamForms()
    connectWebSocket()
    
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect()
      }
    }
  }, [])

  const connectWebSocket = () => {
    try {
      import('socket.io-client').then(({ io }) => {
        socketRef.current = io('/?XTransformPort=3002')
        
        socketRef.current.on('connect', () => {
          console.log('Connected to WebSocket service')
          setIsConnected(true)
        })
        
        socketRef.current.on('disconnect', () => {
          console.log('Disconnected from WebSocket service')
          setIsConnected(false)
        })
        
        socketRef.current.on('matchUpdate', (updatedMatches: Match[]) => {
          setMatches(prevMatches => {
            const newMatches = prevMatches.map(match => {
              const updatedMatch = updatedMatches.find((um: Match) => um.id === match.id)
              return updatedMatch || match
            })
            return newMatches
          })
          setLastUpdate(new Date())
        })
        
        socketRef.current.on('goal', (data: any) => {
          const notification = `⚽ GOAL! ${data.team} scored! ${data.score} (${data.minute}')`
          setNotifications(prev => [notification, ...prev.slice(0, 4)])
        })
        
        socketRef.current.on('matchFinished', (data: any) => {
          const notification = `🏁 Match finished: ${data.finalScore} - Winner: ${data.winner}`
          setNotifications(prev => [notification, ...prev.slice(0, 4)])
        })
      })
    } catch (error) {
      console.error('Failed to connect to WebSocket:', error)
      setIsConnected(false)
    }
  }

  const fetchFixtures = async () => {
    try {
      const response = await fetch('/api/fixtures')
      const data = await response.json()
      if (data.success) {
        setFixtures(data.fixtures || [])
      }
    } catch (error) {
      console.error('Failed to fetch fixtures:', error)
    }
  }

  const fetchPreviousGames = async () => {
    try {
      const response = await fetch('/api/previous-games?type=recent')
      const data = await response.json()
      if (data.success) {
        setPreviousGames(data.games || [])
      }
    } catch (error) {
      console.error('Failed to fetch previous games:', error)
    }
  }

  const fetchHeadToHead = async () => {
    try {
      const response = await fetch('/api/previous-games?type=head2head')
      const data = await response.json()
      if (data.success) {
        setHeadToHead(data.headToHead || [])
      }
    } catch (error) {
      console.error('Failed to fetch head-to-head:', error)
    }
  }

  const fetchTeamForms = async () => {
    try {
      const response = await fetch('/api/previous-games?type=form')
      const data = await response.json()
      if (data.success) {
        setTeamForms(data.teamForms || {})
      }
    } catch (error) {
      console.error('Failed to fetch team forms:', error)
    }
  }

  const fetchLeagues = async () => {
    try {
      const response = await fetch('/api/leagues')
      const data = await response.json()
      if (data.success) {
        setLeagues(data.leagues)
      }
    } catch (error) {
      console.error('Failed to fetch leagues:', error)
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats')
      const data = await response.json()
      if (data.success) {
        setTopScorers(data.topScorers || [])
        setTeamStats(data.teamStats || [])
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error)
    }
  }

  const fetchPrediction = async (match: Match) => {
    try {
      setLoading(true)
      const response = await fetch(
        `/api/predictions?homeTeam=${encodeURIComponent(match.homeTeam)}&awayTeam=${encodeURIComponent(match.awayTeam)}&league=${encodeURIComponent(match.league)}`
      )
      const data = await response.json()
      
      if (data.success && data.prediction) {
        setMatches(prev => prev.map(m => 
          m.id === match.id 
            ? { ...m, prediction: data.prediction }
            : m
        ))
      }
    } catch (error) {
      console.error('Failed to fetch prediction:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string, minute?: number) => {
    switch (status) {
      case 'live':
        return (
          <Badge variant="destructive" className="animate-pulse">
            <Play className="w-3 h-3 mr-1" />
            LIVE {minute && `${minute}'`}
          </Badge>
        )
      case 'finished':
        return <Badge variant="secondary">FT</Badge>
      case 'upcoming':
        return <Badge variant="outline">UPCOMING</Badge>
      default:
        return null
    }
  }

  const getResultBadge = (result: string) => {
    switch (result) {
      case 'W':
        return <Badge className="bg-green-500 text-white">W</Badge>
      case 'L':
        return <Badge className="bg-red-500 text-white">L</Badge>
      case 'D':
        return <Badge className="bg-yellow-500 text-white">D</Badge>
      default:
        return null
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today'
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow'
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    }
  }

  const MatchCard = ({ match }: { match: Match }) => (
    <Card className="hover:shadow-lg transition-shadow relative">
      {match.status === 'live' && (
        <div className="absolute top-2 right-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
        </div>
      )}
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{match.leagueFlag}</span>
            <span className="text-sm font-medium text-muted-foreground">{match.league}</span>
          </div>
          {getStatusBadge(match.status, match.minute)}
        </div>
        {match.venue && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" />
            {match.venue}
            {match.attendance > 0 && (
              <>
                <Separator orientation="vertical" className="h-3" />
                <Users className="w-3 h-3" />
                {match.attendance.toLocaleString()}
              </>
            )}
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{match.homeTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{match.homeTeam}</h3>
          </div>
          <div className="px-4">
            <div className="text-2xl font-bold text-center">
              {match.homeScore} - {match.awayScore}
            </div>
          </div>
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{match.awayTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{match.awayTeam}</h3>
          </div>
        </div>

        {match.status === 'live' && match.homeTeamStats && match.awayTeamStats && (
          <div className="grid grid-cols-2 gap-4 mb-4 p-3 bg-muted rounded-lg">
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>Possession</span>
                <span>{match.homeTeamStats.possession}%</span>
              </div>
              <Progress value={match.homeTeamStats.possession} className="h-1" />
              <div className="flex justify-between text-xs">
                <span>Shots</span>
                <span>{match.homeTeamStats.shots}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span>Corners</span>
                <span>{match.homeTeamStats.corners}</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>Possession</span>
                <span>{match.awayTeamStats.possession}%</span>
              </div>
              <Progress value={match.awayTeamStats.possession} className="h-1" />
              <div className="flex justify-between text-xs">
                <span>Shots</span>
                <span>{match.awayTeamStats.shots}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span>Corners</span>
                <span>{match.awayTeamStats.corners}</span>
              </div>
            </div>
          </div>
        )}
        
        <div className="border-t pt-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-muted-foreground">AI Prediction</span>
            {match.prediction ? (
              <Badge variant="outline" className="text-xs">
                {match.prediction.confidence}% confidence
              </Badge>
            ) : (
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => fetchPrediction(match)}
                disabled={loading}
              >
                {loading ? 'Loading...' : 'Get AI Tip'}
              </Button>
            )}
          </div>
          {match.prediction && (
            <>
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">{match.prediction.winner}</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {match.prediction.tips.map((tip, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {tip}
                  </Badge>
                ))}
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )

  const FixtureCard = ({ fixture }: { fixture: Fixture }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{fixture.leagueFlag}</span>
            <span className="text-sm font-medium text-muted-foreground">{fixture.league}</span>
          </div>
          <Badge variant="outline">{formatDate(fixture.date)}</Badge>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <CalendarDays className="w-3 h-3" />
          {fixture.date} at {fixture.time}
          <Separator orientation="vertical" className="h-3" />
          <MapPin className="w-3 h-3" />
          {fixture.venue}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{fixture.homeTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{fixture.homeTeam}</h3>
          </div>
          <div className="px-4">
            <div className="text-lg font-bold text-center text-muted-foreground">VS</div>
          </div>
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{fixture.awayTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{fixture.awayTeam}</h3>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground mb-3">
          <div className="flex items-center gap-1">
            <Tv className="w-3 h-3" />
            <span className="truncate">{fixture.broadcast}</span>
          </div>
          <div className="flex items-center gap-1">
            <User className="w-3 h-3" />
            <span className="truncate">{fixture.referee}</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            <span>MD {fixture.matchday}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const PreviousGameCard = ({ game }: { game: PreviousGame }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{game.leagueFlag}</span>
            <span className="text-sm font-medium text-muted-foreground">{game.league}</span>
          </div>
          <Badge variant="secondary">{game.date}</Badge>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <MapPin className="w-3 h-3" />
          {game.venue}
          <Separator orientation="vertical" className="h-3" />
          <Users className="w-3 h-3" />
          {game.attendance?.toLocaleString()}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{game.homeTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{game.homeTeam}</h3>
          </div>
          <div className="px-4">
            <div className="text-2xl font-bold text-center">
              {game.homeScore} - {game.awayScore}
            </div>
          </div>
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{game.awayTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{game.awayTeam}</h3>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4 p-3 bg-muted rounded-lg">
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span>Possession</span>
              <span>{game.homeTeamStats.possession}%</span>
            </div>
            <Progress value={game.homeTeamStats.possession} className="h-1" />
            <div className="flex justify-between text-xs">
              <span>xG</span>
              <span>{game.homeTeamStats.xG}</span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span>Possession</span>
              <span>{game.awayTeamStats.possession}%</span>
            </div>
            <Progress value={game.awayTeamStats.possession} className="h-1" />
            <div className="flex justify-between text-xs">
              <span>xG</span>
              <span>{game.awayTeamStats.xG}</span>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">Man of the Match: {game.manOfTheMatch}</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {game.goalscorers.slice(0, 3).map((scorer, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {scorer.player} {scorer.minute}'
              </Badge>
            ))}
            {game.goalscorers.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{game.goalscorers.length - 3} more
              </Badge>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const TeamFormCard = ({ team, form }: { team: string, form: TeamForm[] }) => (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{team}</CardTitle>
        <CardDescription>Last 6 games form</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-4">
          {form.map((game, index) => (
            <div key={index} className="flex-1 text-center">
              {getResultBadge(game.result)}
              <div className="text-xs text-muted-foreground mt-1">
                {game.home ? <Home className="w-3 h-3 mx-auto" /> : <MapPin className="w-3 h-3 mx-auto" />}
              </div>
              <div className="text-xs font-medium mt-1">{game.score}</div>
              <div className="text-xs text-muted-foreground truncate">{game.opponent.slice(0, 3)}</div>
            </div>
          ))}
        </div>
        <div className="text-sm">
          <div className="flex justify-between">
            <span>Form:</span>
            <span className="font-medium">{form.filter(g => g.result === 'W').length}W {form.filter(g => g.result === 'D').length}D {form.filter(g => g.result === 'L').length}L</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Trophy className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">Football Live</h1>
                <p className="text-sm text-muted-foreground">AI-Powered Scores & Predictions</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                {isConnected ? (
                  <>
                    <Wifi className="w-4 h-4 text-green-500" />
                    <span className="text-green-500">Live</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="w-4 h-4 text-red-500" />
                    <span className="text-red-500">Offline</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                Last updated: {lastUpdate.toLocaleTimeString()}
              </div>
              <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
          
          {notifications.length > 0 && (
            <div className="mt-4 space-y-2">
              {notifications.map((notification, index) => (
                <div key={index} className="p-2 bg-primary/10 border border-primary/20 rounded-lg text-sm animate-pulse">
                  <Bell className="w-4 h-4 inline mr-2" />
                  {notification}
                </div>
              ))}
            </div>
          )}
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <TabsList className="grid w-full sm:w-auto grid-cols-3 lg:grid-cols-6">
              <TabsTrigger value="livescore" className="flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Live
              </TabsTrigger>
              <TabsTrigger value="fixtures" className="flex items-center gap-2">
                <CalendarDays className="w-4 h-4" />
                Fixtures
              </TabsTrigger>
              <TabsTrigger value="previous" className="flex items-center gap-2">
                <History className="w-4 h-4" />
                Results
              </TabsTrigger>
              <TabsTrigger value="stats" className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Stats
              </TabsTrigger>
              <TabsTrigger value="head2head" className="flex items-center gap-2">
                <TargetIcon className="w-4 h-4" />
                H2H
              </TabsTrigger>
              <TabsTrigger value="predictions" className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                AI Tips
              </TabsTrigger>
            </TabsList>
            
            <Select value={selectedLeague} onValueChange={setSelectedLeague}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by league" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Leagues</SelectItem>
                {leagues.map((league) => (
                  <SelectItem key={league.id} value={league.id}>
                    {league.flag} {league.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <TabsContent value="livescore" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {matches.map((match) => (
                <MatchCard key={match.id} match={match} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="fixtures" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {fixtures.map((fixture) => (
                <FixtureCard key={fixture.id} fixture={fixture} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="previous" className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {previousGames.map((game) => (
                <PreviousGameCard key={game.id} game={game} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="head2head" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              {headToHead.map((h2h, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TargetIcon className="w-5 h-5" />
                      {h2h.team1} vs {h2h.team2}
                    </CardTitle>
                    <CardDescription>Head-to-head record</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{h2h.team1Wins}</div>
                        <div className="text-sm text-muted-foreground">{h2h.team1}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-yellow-600">{h2h.draws}</div>
                        <div className="text-sm text-muted-foreground">Draws</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{h2h.team2Wins}</div>
                        <div className="text-sm text-muted-foreground">{h2h.team2}</div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="text-center">
                        <div className="text-lg font-semibold">{h2h.team1Goals}</div>
                        <div className="text-sm text-muted-foreground">Goals</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold">{h2h.team2Goals}</div>
                        <div className="text-sm text-muted-foreground">Goals</div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-3">Last 5 Matches</h4>
                      <div className="space-y-2">
                        {h2h.last5Matches.map((match, matchIndex) => (
                          <div key={matchIndex} className="flex items-center justify-between p-2 border rounded">
                            <div className="text-sm">
                              {match.date} - {match.homeTeam} vs {match.awayTeam}
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{match.homeScore} - {match.awayScore}</span>
                              {getResultBadge(match.result)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {Object.entries(teamForms).map(([team, form]) => (
                <TeamFormCard key={team} team={team} form={form} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="stats" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5" />
                    Top Scorers
                  </CardTitle>
                  <CardDescription>Leading goal scorers across all leagues</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-4">
                      {topScorers.slice(0, 10).map((scorer) => (
                        <div key={scorer.rank} className="flex items-center justify-between p-3 rounded-lg border">
                          <div className="flex items-center gap-3">
                            <Badge variant="outline" className="w-8 h-8 rounded-full flex items-center justify-center">
                              {scorer.rank}
                            </Badge>
                            <Avatar className="w-10 h-10">
                              <AvatarFallback>{scorer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{scorer.name}</p>
                              <p className="text-sm text-muted-foreground">{scorer.team}</p>
                              <Badge variant="secondary" className="text-xs mt-1">{scorer.league}</Badge>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm">
                            <div className="text-center">
                              <p className="font-bold text-lg">{scorer.goals}</p>
                              <p className="text-muted-foreground">Goals</p>
                            </div>
                            <div className="text-center">
                              <p className="font-medium">{scorer.assists}</p>
                              <p className="text-muted-foreground">Assists</p>
                            </div>
                            <div className="text-center">
                              <p className="font-medium">{scorer.matches}</p>
                              <p className="text-muted-foreground">Matches</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Team Statistics
                  </CardTitle>
                  <CardDescription>Top performing teams this season</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-4">
                      {teamStats.map((team, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <h3 className="font-semibold">{team.team}</h3>
                              <Badge variant="outline" className="text-xs">{team.league}</Badge>
                            </div>
                            <div className="text-right">
                              <div className="text-lg font-bold">{team.points || (team.won * 3 + team.drawn)} pts</div>
                              <div className="text-sm text-muted-foreground">
                                {team.played} games
                              </div>
                            </div>
                          </div>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div className="text-center">
                              <div className="font-medium text-green-600">{team.won}</div>
                              <div className="text-muted-foreground">Won</div>
                            </div>
                            <div className="text-center">
                              <div className="font-medium text-yellow-600">{team.drawn}</div>
                              <div className="text-muted-foreground">Drawn</div>
                            </div>
                            <div className="text-center">
                              <div className="font-medium text-red-600">{team.lost}</div>
                              <div className="text-muted-foreground">Lost</div>
                            </div>
                          </div>
                          <div className="mt-3 pt-3 border-t grid grid-cols-2 gap-4 text-xs">
                            <div className="flex justify-between">
                              <span>Goals:</span>
                              <span>{team.goalsFor}:{team.goalsAgainst}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Clean Sheets:</span>
                              <span>{team.cleanSheets}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Possession:</span>
                              <span>{team.possession}%</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Pass Acc:</span>
                              <span>{team.passAccuracy}%</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="predictions" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Today's AI Predictions
                  </CardTitle>
                  <CardDescription>Machine-powered match analysis and tips</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {matches.filter(m => m.prediction).map((match) => (
                      <div key={match.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="font-medium">
                            {match.homeTeam} vs {match.awayTeam}
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{match.prediction?.confidence}%</Badge>
                            <Button size="sm" variant="ghost">
                              <ThumbsUp className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="ghost">
                              <ThumbsDown className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-green-600" />
                            <span className="text-sm">Prediction: {match.prediction?.winner}</span>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {match.prediction?.tips.map((tip, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {tip}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    AI Accuracy Stats
                  </CardTitle>
                  <CardDescription>Our prediction performance this week</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Overall Accuracy</span>
                        <span className="text-sm text-muted-foreground">78%</span>
                      </div>
                      <Progress value={78} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Match Winner</span>
                        <span className="text-sm text-muted-foreground">82%</span>
                      </div>
                      <Progress value={82} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Over/Under Goals</span>
                        <span className="text-sm text-muted-foreground">71%</span>
                      </div>
                      <Progress value={71} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Both Teams Score</span>
                        <span className="text-sm text-muted-foreground">69%</span>
                      </div>
                      <Progress value={69} className="h-2" />
                    </div>
                    <div className="pt-4 border-t">
                      <div className="flex items-center justify-between text-sm">
                        <span>Total Predictions</span>
                        <span className="font-medium">156</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Successful</span>
                        <span className="font-medium text-green-600">122</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Failed</span>
                        <span className="font-medium text-red-600">34</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}