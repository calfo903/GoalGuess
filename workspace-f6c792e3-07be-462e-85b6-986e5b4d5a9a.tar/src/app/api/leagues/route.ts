import { NextResponse } from 'next/server'

const mockLeagues = [
  { 
    id: '1', 
    name: 'Premier League', 
    country: 'England', 
    flag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿', 
    matches: 380, 
    teams: 20,
    season: '2023/24',
    startDate: '2023-08-11',
    endDate: '2024-05-19'
  },
  { 
    id: '2', 
    name: 'La Liga', 
    country: 'Spain', 
    flag: '🇪🇸', 
    matches: 380, 
    teams: 20,
    season: '2023/24',
    startDate: '2023-08-11',
    endDate: '2024-05-26'
  },
  { 
    id: '3', 
    name: 'Bundesliga', 
    country: 'Germany', 
    flag: '🇩🇪', 
    matches: 306, 
    teams: 18,
    season: '2023/24',
    startDate: '2023-08-18',
    endDate: '2024-05-18'
  },
  { 
    id: '4', 
    name: 'Serie A', 
    country: 'Italy', 
    flag: '🇮🇹', 
    matches: 380, 
    teams: 20,
    season: '2023/24',
    startDate: '2023-08-19',
    endDate: '2024-05-26'
  },
  { 
    id: '5', 
    name: 'Ligue 1', 
    country: 'France', 
    flag: '🇫🇷', 
    matches: 380, 
    teams: 20,
    season: '2023/24',
    startDate: '2023-08-11',
    endDate: '2024-05-25'
  },
  {
    id: '6',
    name: 'Champions League',
    country: 'Europe',
    flag: '🏆',
    matches: 125,
    teams: 32,
    season: '2023/24',
    startDate: '2023-09-19',
    endDate: '2024-06-01'
  },
  {
    id: '7',
    name: 'Europa League',
    country: 'Europe',
    flag: '🌍',
    matches: 141,
    teams: 32,
    season: '2023/24',
    startDate: '2023-09-21',
    endDate: '2024-05-22'
  }
]

const mockStandings = {
  '1': [ // Premier League
    { position: 1, team: 'Manchester City', played: 25, won: 18, drawn: 4, lost: 3, goalsFor: 52, goalsAgainst: 24, points: 58 },
    { position: 2, team: 'Liverpool', played: 25, won: 17, drawn: 5, lost: 3, goalsFor: 48, goalsAgainst: 22, points: 56 },
    { position: 3, team: 'Arsenal', played: 25, won: 16, drawn: 5, lost: 4, goalsFor: 45, goalsAgainst: 23, points: 53 },
    { position: 4, team: 'Chelsea', played: 25, won: 14, drawn: 6, lost: 5, goalsFor: 42, goalsAgainst: 28, points: 48 },
    { position: 5, team: 'Tottenham', played: 25, won: 13, drawn: 5, lost: 7, goalsFor: 40, goalsAgainst: 30, points: 44 }
  ],
  '2': [ // La Liga
    { position: 1, team: 'Real Madrid', played: 24, won: 19, drawn: 3, lost: 2, goalsFor: 46, goalsAgainst: 16, points: 60 },
    { position: 2, team: 'Barcelona', played: 24, won: 18, drawn: 4, lost: 2, goalsFor: 42, goalsAgainst: 18, points: 58 },
    { position: 3, team: 'Girona', played: 24, won: 16, drawn: 5, lost: 3, goalsFor: 44, goalsAgainst: 25, points: 53 },
    { position: 4, team: 'Atletico Madrid', played: 24, won: 14, drawn: 4, lost: 6, goalsFor: 35, goalsAgainst: 22, points: 46 },
    { position: 5, team: 'Athletic Bilbao', played: 24, won: 13, drawn: 6, lost: 5, goalsFor: 38, goalsAgainst: 27, points: 45 }
  ]
}

export async function GET() {
  return NextResponse.json({
    success: true,
    leagues: mockLeagues,
    timestamp: new Date().toISOString()
  })
}