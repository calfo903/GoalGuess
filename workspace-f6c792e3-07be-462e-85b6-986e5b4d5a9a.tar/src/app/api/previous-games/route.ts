import { NextResponse } from 'next/server'

const mockPreviousGames = [
  // Recent Premier League matches
  {
    id: 'pg1',
    homeTeam: 'Manchester City',
    awayTeam: 'Liverpool',
    homeScore: 3,
    awayScore: 1,
    date: '2024-02-10',
    time: '17:30',
    league: 'Premier League',
    leagueFlag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿',
    venue: 'Etihad Stadium',
    status: 'finished',
    matchday: 24,
    attendance: 55000,
    homeTeamStats: {
      possession: 65,
      shots: 18,
      shotsOnTarget: 8,
      corners: 9,
      fouls: 7,
      yellowCards: 2,
      redCards: 0,
      xG: 3.2,
      xGA: 0.8
    },
    awayTeamStats: {
      possession: 35,
      shots: 9,
      shotsOnTarget: 3,
      corners: 4,
      fouls: 11,
      yellowCards: 3,
      redCards: 0,
      xG: 1.1,
      xGA: 3.2
    },
    goalscorers: [
      { player: 'Erling Haaland', team: 'Manchester City', minute: 12, type: 'goal' },
      { player: 'Mohamed Salah', team: 'Liverpool', minute: 28, type: 'penalty' },
      { player: 'Erling Haaland', team: 'Manchester City', minute: 55, type: 'goal' },
      { player: 'Kevin De Bruyne', team: 'Manchester City', minute: 78, type: 'goal' }
    ],
    manOfTheMatch: 'Erling Haaland'
  },
  {
    id: 'pg2',
    homeTeam: 'Arsenal',
    awayTeam: 'Chelsea',
    homeScore: 2,
    awayScore: 2,
    date: '2024-02-09',
    time: '20:00',
    league: 'Premier League',
    leagueFlag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿',
    venue: 'Emirates Stadium',
    status: 'finished',
    matchday: 24,
    attendance: 60384,
    homeTeamStats: {
      possession: 58,
      shots: 15,
      shotsOnTarget: 6,
      corners: 7,
      fouls: 9,
      yellowCards: 2,
      redCards: 0,
      xG: 2.1,
      xGA: 1.8
    },
    awayTeamStats: {
      possession: 42,
      shots: 12,
      shotsOnTarget: 5,
      corners: 5,
      fouls: 8,
      yellowCards: 3,
      redCards: 0,
      xG: 1.8,
      xGA: 2.1
    },
    goalscorers: [
      { player: 'Bukayo Saka', team: 'Arsenal', minute: 18, type: 'goal' },
      { player: 'Cole Palmer', team: 'Chelsea', minute: 35, type: 'goal' },
      { player: 'Kai Havertz', team: 'Arsenal', minute: 67, type: 'goal' },
      { player: 'Conor Gallagher', team: 'Chelsea', minute: 89, type: 'goal' }
    ],
    manOfTheMatch: 'Bukayo Saka'
  },
  // Recent La Liga matches
  {
    id: 'pg3',
    homeTeam: 'Real Madrid',
    awayTeam: 'Girona',
    homeScore: 4,
    awayScore: 0,
    date: '2024-02-10',
    time: '20:00',
    league: 'La Liga',
    leagueFlag: '🇪🇸',
    venue: 'Santiago Bernabéu',
    status: 'finished',
    matchday: 24,
    attendance: 78000,
    homeTeamStats: {
      possession: 62,
      shots: 20,
      shotsOnTarget: 10,
      corners: 8,
      fouls: 6,
      yellowCards: 1,
      redCards: 0,
      xG: 3.8,
      xGA: 0.6
    },
    awayTeamStats: {
      possession: 38,
      shots: 8,
      shotsOnTarget: 2,
      corners: 3,
      fouls: 10,
      yellowCards: 2,
      redCards: 0,
      xG: 0.6,
      xGA: 3.8
    },
    goalscorers: [
      { player: 'Jude Bellingham', team: 'Real Madrid', minute: 22, type: 'goal' },
      { player: 'Vinícius Jr', team: 'Real Madrid', minute: 38, type: 'goal' },
      { player: 'Rodrygo', team: 'Real Madrid', minute: 55, type: 'goal' },
      { player: 'Jude Bellingham', team: 'Real Madrid', minute: 71, type: 'goal' }
    ],
    manOfTheMatch: 'Jude Bellingham'
  },
  {
    id: 'pg4',
    homeTeam: 'Barcelona',
    awayTeam: 'Athletic Bilbao',
    homeScore: 1,
    awayScore: 0,
    date: '2024-02-08',
    time: '21:00',
    league: 'La Liga',
    leagueFlag: '🇪🇸',
    venue: 'Montjuïc',
    status: 'finished',
    matchday: 24,
    attendance: 45000,
    homeTeamStats: {
      possession: 68,
      shots: 16,
      shotsOnTarget: 7,
      corners: 10,
      fouls: 8,
      yellowCards: 2,
      redCards: 0,
      xG: 2.2,
      xGA: 0.4
    },
    awayTeamStats: {
      possession: 32,
      shots: 6,
      shotsOnTarget: 2,
      corners: 2,
      fouls: 12,
      yellowCards: 4,
      redCards: 0,
      xG: 0.4,
      xGA: 2.2
    },
    goalscorers: [
      { player: 'Robert Lewandowski', team: 'Barcelona', minute: 83, type: 'penalty' }
    ],
    manOfTheMatch: 'Robert Lewandowski'
  },
  // Recent Champions League matches
  {
    id: 'pg5',
    homeTeam: 'Manchester City',
    awayTeam: 'Copenhagen',
    homeScore: 3,
    awayScore: 1,
    date: '2024-02-06',
    time: '20:00',
    league: 'Champions League',
    leagueFlag: '🏆',
    venue: 'Etihad Stadium',
    status: 'finished',
    matchday: 'Round of 16',
    attendance: 52000,
    homeTeamStats: {
      possession: 70,
      shots: 22,
      shotsOnTarget: 11,
      corners: 12,
      fouls: 5,
      yellowCards: 1,
      redCards: 0,
      xG: 4.1,
      xGA: 0.8
    },
    awayTeamStats: {
      possession: 30,
      shots: 7,
      shotsOnTarget: 3,
      corners: 2,
      fouls: 14,
      yellowCards: 3,
      redCards: 0,
      xG: 0.8,
      xGA: 4.1
    },
    goalscorers: [
      { player: 'Phil Foden', team: 'Manchester City', minute: 24, type: 'goal' },
      { player: 'Phil Foden', team: 'Manchester City', minute: 39, type: 'goal' },
      { player: 'Mohamed Elyounoussi', team: 'Copenhagen', minute: 45, type: 'goal' },
      { player: 'Erling Haaland', team: 'Manchester City', minute: 90, type: 'penalty' }
    ],
    manOfTheMatch: 'Phil Foden'
  }
]

// Head-to-head records
const headToHeadRecords = [
  {
    team1: 'Manchester City',
    team2: 'Liverpool',
    totalMatches: 58,
    team1Wins: 28,
    team2Wins: 20,
    draws: 10,
    team1Goals: 89,
    team2Goals: 71,
    last5Matches: [
      { date: '2024-02-10', homeTeam: 'Manchester City', awayTeam: 'Liverpool', homeScore: 3, awayScore: 1, result: 'H' },
      { date: '2023-11-25', homeTeam: 'Liverpool', awayTeam: 'Manchester City', homeScore: 1, awayScore: 1, result: 'D' },
      { date: '2023-04-01', homeTeam: 'Manchester City', awayTeam: 'Liverpool', homeScore: 4, awayScore: 1, result: 'H' },
      { date: '2022-10-16', homeTeam: 'Liverpool', awayTeam: 'Manchester City', homeScore: 1, awayScore: 0, result: 'H' },
      { date: '2022-04-03', homeTeam: 'Manchester City', awayTeam: 'Liverpool', homeScore: 2, awayScore: 2, result: 'D' }
    ]
  },
  {
    team1: 'Real Madrid',
    team2: 'Barcelona',
    totalMatches: 254,
    team1Wins: 102,
    team2Wins: 100,
    draws: 52,
    team1Goals: 424,
    team2Goals: 398,
    last5Matches: [
      { date: '2024-01-14', homeTeam: 'Real Madrid', awayTeam: 'Barcelona', homeScore: 4, awayScore: 1, result: 'H' },
      { date: '2023-10-28', homeTeam: 'Barcelona', awayTeam: 'Real Madrid', homeScore: 1, awayScore: 2, result: 'A' },
      { date: '2023-04-05', homeTeam: 'Real Madrid', awayTeam: 'Barcelona', homeScore: 0, awayScore: 4, result: 'A' },
      { date: '2023-01-19', homeTeam: 'Barcelona', awayTeam: 'Real Madrid', homeScore: 1, awayScore: 3, result: 'A' },
      { date: '2022-10-16', homeTeam: 'Real Madrid', awayTeam: 'Barcelona', homeScore: 3, awayScore: 1, result: 'H' }
    ]
  }
]

// Team form (last 6 games)
const teamForm = {
  'Manchester City': [
    { opponent: 'Liverpool', result: 'W', score: '3-1', home: true },
    { opponent: 'Burnley', result: 'W', score: '2-0', home: false },
    { opponent: 'Sheffield United', result: 'W', score: '2-1', home: true },
    { opponent: 'Newcastle', result: 'D', score: '2-2', home: false },
    { opponent: 'Crystal Palace', result: 'W', score: '2-1', home: true },
    { opponent: 'Everton', result: 'W', score: '3-1', home: false }
  ],
  'Liverpool': [
    { opponent: 'Manchester City', result: 'L', score: '1-3', home: false },
    { opponent: 'Burnley', result: 'W', score: '3-1', home: true },
    { opponent: 'Chelsea', result: 'W', score: '4-1', home: false },
    { opponent: 'Arsenal', result: 'D', score: '1-1', home: true },
    { opponent: 'Fulham', result: 'W', score: '3-1', home: false },
    { opponent: 'Crystal Palace', result: 'W', score: '2-1', home: true }
  ],
  'Real Madrid': [
    { opponent: 'Girona', result: 'W', score: '4-0', home: true },
    { opponent: 'Atletico Madrid', result: 'W', score: '2-1', home: false },
    { opponent: 'Almeria', result: 'W', score: '3-2', home: true },
    { opponent: 'Real Betis', result: 'W', score: '1-0', home: false },
    { opponent: 'Valencia', result: 'W', score: '5-1', home: true },
    { opponent: 'Alaves', result: 'D', score: '1-1', home: false }
  ]
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const league = searchParams.get('league')
  const team = searchParams.get('team')
  const type = searchParams.get('type') // 'recent', 'head2head', 'form'
  const team1 = searchParams.get('team1')
  const team2 = searchParams.get('team2')

  try {
    switch (type) {
      case 'head2head':
        if (team1 && team2) {
          const h2h = headToHeadRecords.find(record => 
            (record.team1 === team1 && record.team2 === team2) ||
            (record.team1 === team2 && record.team2 === team1)
          )
          return NextResponse.json({
            success: true,
            headToHead: h2h || null,
            timestamp: new Date().toISOString()
          })
        }
        return NextResponse.json({
          success: true,
          headToHead: headToHeadRecords,
          timestamp: new Date().toISOString()
        })

      case 'form':
        if (team && teamForm[team as keyof typeof teamForm]) {
          return NextResponse.json({
            success: true,
            team,
            form: teamForm[team as keyof typeof teamForm],
            timestamp: new Date().toISOString()
          })
        }
        return NextResponse.json({
          success: true,
          teamForms: teamForm,
          timestamp: new Date().toISOString()
        })

      case 'recent':
      default:
        let filteredGames = [...mockPreviousGames]

        // Filter by league
        if (league && league !== 'all') {
          filteredGames = filteredGames.filter(game => 
            game.league.toLowerCase().includes(league.toLowerCase())
          )
        }

        // Filter by team
        if (team) {
          filteredGames = filteredGames.filter(game => 
            game.homeTeam.toLowerCase().includes(team.toLowerCase()) ||
            game.awayTeam.toLowerCase().includes(team.toLowerCase())
          )
        }

        // Sort by date (most recent first)
        filteredGames.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

        return NextResponse.json({
          success: true,
          games: filteredGames,
          total: filteredGames.length,
          timestamp: new Date().toISOString()
        })
    }
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch previous games' },
      { status: 500 }
    )
  }
}