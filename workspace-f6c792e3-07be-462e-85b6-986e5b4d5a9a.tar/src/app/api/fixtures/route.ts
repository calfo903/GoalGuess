import { NextResponse } from 'next/server'

const mockFixtures = [
  // Today's fixtures
  {
    id: 'f1',
    homeTeam: 'Chelsea',
    awayTeam: 'Arsenal',
    date: new Date().toISOString().split('T')[0],
    time: '20:00',
    league: 'Premier League',
    leagueFlag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿',
    venue: 'Stamford Bridge',
    status: 'upcoming',
    matchday: 26,
    broadcast: 'Sky Sports',
    referee: 'Michael Oliver'
  },
  {
    id: 'f2',
    homeTeam: 'Tottenham',
    awayTeam: 'West Ham',
    date: new Date().toISOString().split('T')[0],
    time: '20:15',
    league: 'Premier League',
    leagueFlag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿',
    venue: 'Tottenham Hotspur Stadium',
    status: 'upcoming',
    matchday: 26,
    broadcast: 'BT Sport',
    referee: 'Anthony Taylor'
  },
  // Tomorrow's fixtures
  {
    id: 'f3',
    homeTeam: 'Atletico Madrid',
    awayTeam: 'Sevilla',
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    time: '18:30',
    league: 'La Liga',
    leagueFlag: '🇪🇸',
    venue: 'Metropolitano Stadium',
    status: 'upcoming',
    matchday: 25,
    broadcast: 'DAZN',
    referee: 'Jose Luis Munuera'
  },
  {
    id: 'f4',
    homeTeam: 'AC Milan',
    awayTeam: 'Inter Milan',
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    time: '20:45',
    league: 'Serie A',
    leagueFlag: '🇮🇹',
    venue: 'San Siro',
    status: 'upcoming',
    matchday: 24,
    broadcast: 'DAZN',
    referee: 'Maurizio Mariani'
  },
  // This week fixtures
  {
    id: 'f5',
    homeTeam: 'Bayern Munich',
    awayTeam: 'Bayer Leverkusen',
    date: new Date(Date.now() + 172800000).toISOString().split('T')[0],
    time: '20:30',
    league: 'Bundesliga',
    leagueFlag: '🇩🇪',
    venue: 'Allianz Arena',
    status: 'upcoming',
    matchday: 21,
    broadcast: 'Sky Sport',
    referee: 'Sven Jablonski'
  },
  {
    id: 'f6',
    homeTeam: 'PSG',
    awayTeam: 'Nice',
    date: new Date(Date.now() + 259200000).toISOString().split('T')[0],
    time: '21:00',
    league: 'Ligue 1',
    leagueFlag: '🇫🇷',
    venue: 'Parc des Princes',
    status: 'upcoming',
    matchday: 22,
    broadcast: 'Canal+',
    referee: 'Jerome Pignard'
  },
  // Champions League fixtures
  {
    id: 'f7',
    homeTeam: 'Manchester City',
    awayTeam: 'Real Madrid',
    date: new Date(Date.now() + 345600000).toISOString().split('T')[0],
    time: '20:00',
    league: 'Champions League',
    leagueFlag: '🏆',
    venue: 'Etihad Stadium',
    status: 'upcoming',
    matchday: 'Round of 16',
    broadcast: 'BT Sport',
    referee: 'Daniele Orsato'
  },
  {
    id: 'f8',
    homeTeam: 'Bayern Munich',
    awayTeam: 'Arsenal',
    date: new Date(Date.now() + 432000000).toISOString().split('T')[0],
    time: '20:00',
    league: 'Champions League',
    leagueFlag: '🏆',
    venue: 'Allianz Arena',
    status: 'upcoming',
    matchday: 'Round of 16',
    broadcast: 'Sony Ten',
    referee: 'Felix Zwayer'
  }
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const league = searchParams.get('league')
  const date = searchParams.get('date')
  const team = searchParams.get('team')

  try {
    let filteredFixtures = [...mockFixtures]

    // Filter by league
    if (league && league !== 'all') {
      filteredFixtures = filteredFixtures.filter(fixture => 
        fixture.league.toLowerCase().includes(league.toLowerCase())
      )
    }

    // Filter by date
    if (date) {
      filteredFixtures = filteredFixtures.filter(fixture => 
        fixture.date === date
      )
    }

    // Filter by team
    if (team) {
      filteredFixtures = filteredFixtures.filter(fixture => 
        fixture.homeTeam.toLowerCase().includes(team.toLowerCase()) ||
        fixture.awayTeam.toLowerCase().includes(team.toLowerCase())
      )
    }

    // Group fixtures by date
    const fixturesByDate = filteredFixtures.reduce((acc, fixture) => {
      if (!acc[fixture.date]) {
        acc[fixture.date] = []
      }
      acc[fixture.date].push(fixture)
      return acc
    }, {} as Record<string, typeof mockFixtures>)

    return NextResponse.json({
      success: true,
      fixtures: filteredFixtures,
      fixturesByDate,
      total: filteredFixtures.length,
      timestamp: new Date().toISOString()
    })

  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch fixtures' },
      { status: 500 }
    )
  }
}